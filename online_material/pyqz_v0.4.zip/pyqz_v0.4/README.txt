  Python module : pyqz.py
  Version : 0.4 - Released July 2013 
  Copyright 2013 Fr�d�ric Vogt
 
  This file is part of the pyqz Python module.
 
    The pyqz Python module is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, version 3 of the License.
 
     The pyqz Python module is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
 
     You should have received a copy of the GNU General Public License
     along with the pyqz Python module.  If not, see <http://www.gnu.org/licenses/>.
 
 ====================================================================================== 
  --------------------------------- README -------------------------------------------
 ======================================================================================

  -------------
  Introduction:
  This program returns the values of log(q) and 12+log(O/H) following the 
  latest MAPPINGS IV simulations, and different kappa values, as described in
 
  Dopita et al., New Strong Line Abundance Diagnostics for H ii Regions: 
  Effects of Updated Atomic Data and kappa-Distributed Electron Energies, 
  Apj (2013).
 
  -------------
  Installation: 
  Place the ./pyqz folder anywhere, and add its location
  to your Python path (e.g. in your .bash_profile for example). You should
  also define the global variable PYQZ_DIR (or directly modify line 84 of 
  the pyqz.py file if you don't have easy access to your Python path. 
 
  In my case (on a MAC OSX), my .bash_profile would look like :
 
  export PYTHONPATH=$PYTHONPATH:/Users/fvogt/Tools/Python/fpav_pylib/pyqz/
  export PYQZ_DIR='/Users/fvogt/Tools/Python/fpav_pylib/pyqz/'
 
  ----------------------------------
  Usage example (in a Terminal, via a Python shell):
 
  user% ipython --pylab
  user% import pyqz
 
  user% pyqz.get_qz(kappa,qz,ratios1,ratios2,ratio_name1, ratio_name2, method='default', plot=True/False, n_plot = False, savefig=False )
 
  Or, for batch processing (with kappa = 20 in this example):
  user% pyqz.get_qzff(20,'Input.txt')
 
  where input file has format:
  OIII/Hb OI/Ha NII/Ha SII/Ha OIII/OII OIII/NII OIII/SII NII/SII NII/OII NII/OII;OIII/OII NII/OII;OIII/Hb NII/OII;OIII/SII NII/SII;OIII/OII NII/SII;OIII/Hb NII/SII;OIII/SII
 -0.0362 -1.1552 -0.461	-0.3545	-0.8338	-0.0314	-0.138	-0.1066	-0.8023  ......
 -0.2007 -1.0548 -0.4062 -0.3628 -0.8145 -0.2507 -0.2941 -0.0434 -0.5638
 
  The exact list of ratios and diagnostic inside the input file is modifiable 
  (as long as any diagnostic is supported by pyqz, and the necessary line ratios are included).
  Missing values should be noted as '$$$'.
  This command then outputs a .csv file "Input_out_k20.csv" with the output q and Z in the same directory
  Experienced Python users should be able to use pyqz in their script easily after importing the module.
 
  -----------------------
  More examples :
 
  To see the test plots :
  pyqz.get_qz(20,'z',pyqz.grid_x,pyqz.grid_y,'NII/OII',
  'OIII/SII',plot=True,method='default')
 
  To load a diagnostic grid (useful to plot it in a BPT diagram) :
  pyqz.get_grid(kappa,name1,name2)
 
  ----------
  Keywords :
 
  kappa : the kappa value (required). print pyqz.kappas returns a list of 
          available kappa values ; [10,20,60,np.inf]
 
  qz : 'q' or 'z' (required). Which grid to read; 
       'q' -> log(q) and 'z' -> 12+log(O/H) 
 
  ratios1,ratios2 : your measured line ratios (required). Needs to be a numpy array (1D or 2D) !
 
  ratio_name1,ratio_name2 : which ratios you have (required). X-AXIS IS  FIRST ! 
                            pyqz.diagnostics.keys() shows the allowed diagnostics. 
                            Format : 'NII/SII', 'OIII/Hb', etc ... 
                            Allowed ratios are : 
 	'NII/SII;OIII/SII',
 	'NII/SII;OIII/Hb', 
 	'NII/SII;OIII/OII',
 	'NII/OII;OIII/SII',
  	'NII/OII;OIII/Hb',
  	'NII/OII;OIII/OII',
 	'NII/Ha;OIII/Hb',
 	'NII/Ha;OIII/OII'
 
  plot : True/False (optional).
 
  method : 'default','linear','cubic' (optional). Which interpolation
            method to use (relies on scipy.interpolate.griddata)
 
  n_plot : False, 1, 2, 3, � . The number of the plot window created. 
           Setting to False will just take the next available slot.
 
  savefig : False, 'path/to/somehwere/figname.extension'. If False, does nothing. 
            Else, saves the figure at the location '/path/to/somewhere/', 
            with the name 'figname' and the format 'extension'. 
           Supports png, eps and pdf (and others).
 
  -----------------
  Troubleshooting :
 
  While this code should be fairly straightforward to use, limited support may
  (or may not ...;-) be available by contacting 'fvogt -at- mso.anu.edu.au'.
  Bug reports are always welcome, though !
 
  -----------
  Reference :
 
  If you find this code useful, please cite the corresponding paper
 
  Dopita et al., ApJ (2013).
 
 

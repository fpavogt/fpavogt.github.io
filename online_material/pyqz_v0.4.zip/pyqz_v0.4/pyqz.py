# -*- coding: utf-8 -*-
#
# This program returns the values of log(q) and 12+log(O/H) following the 
# latest MAPPINGS IV simulations, and different kappa values.
#
# See the README file for installation and usage instructions.
#
# v0.1 Feb. 2013
# - created
# v0.2 April 2013, F.Vogt
# - modified fitting method to be 'slice-by-slice' for smoother results
# - added the get_grid function
# - added different readable areas for different grids and kappas
# v0.3 April 2003, F.Vogt
# - added get_qzff function to directly work from a txt file
# - corrected get_pyqz for when points are 'on' the grid.
# ---- v0.3.1 -----
# - added .csv output for the get_qzff (or txt, which ever you like best)
# - changed header column of output files (only 'z' is used for consistency)
# ---- v0.3.1b ----
# - fixed indentation of 4 lines in get_qzff
# ---- v0.3.2 ----
# Implemented the following updates following suggestions by DN (06.06.2013):
# - added 'smart' plot limits (instead of fixed ones)
# - increased grid and data point size
# - added new keyword for choosing the plot window number (n_plot)
# - added 'if' statement to close the plot if all values are NaNs (removed in v0.4)
# - added plot title
# ---- v0.3.2b ----
# - corrected bug related to integer line ratios (e.g. [0],[0]) 
# - corrected bug related to the step checking if line ratios are on the MAPPINGS IV grid
# ---- v0.3.3 ----
# - now also displays the points landing outside the grid model with white triangles 
#   (only for the 1-D array input type)
# ---- v0.4 ------
# - fixed several bugs related with 2D input arrays
# - limited the number of bad points plotted to 1500 
#   (for compatibility with grid_x and grid_y)
# - clarified the required input structure - must be numpy arrays (1D or 2D)
# - plots are now prettier, and more robust (defined via local rcParams)
# - added possibility to save plot via 'savefig' keyword
# - improved axis labels in the plots to make them 'publication-ready' 
#   (if one wanted to)
#
# If you find this code useful, please cite the corresponding paper
#
# Dopita et al., ApJ (2013).
#
# Copyright 2013 Frédéric Vogt (fvogt -at- mso.anu.edu.au)
#
# This file is part of the pyqz Python module.
#
#   The pyqz Python module is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, version 3 of the License.
#
#    The pyqz Pythonn module is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with the pyqz Python module.  If not, see <http://www.gnu.org/licenses/>.

import numpy as np
import scipy as sp
from scipy import interpolate
from matplotlib import pyplot as plt
from matplotlib.path import Path
import matplotlib.patches as patches
import matplotlib.gridspec as gridspec
from matplotlib.colorbar import Colorbar
import os
import scipy.stats.stats as stats
from datetime import datetime as dt

# Define the version of pyqz
__version__ = '0.4'

# If you set the environment variable 'PYQZ_DIR' then it will be found
mdir = os.getenv('PYQZ_DIR')
# OTHERWISE YOU MUST SET IT HERE BY HAND
if mdir == None:
    pyqz_dir = '/Users/fvogt/Tools/Python/fpav_pylib/pyqz_v0.4/'
else:
    pyqz_dir = mdir

# --- Make the plots look good ----
import matplotlib as mpl
# Use mathtext
#'''
mpl.rc('font',**{'family':'sans-serif', 'serif':['Bitstream Vera Serif'], 
                 'sans-serif':['Helvetica'], 'size':20, 
                 'weight':'normal'})
mpl.rc('axes',**{'labelweight':'bold', 'linewidth':1})
mpl.rc('ytick',**{'major.pad':8, 'color':'k'})
mpl.rc('xtick',**{'major.pad':8, 'color':'k'})
mpl.rc('mathtext',**{'default':'regular','fontset':'cm', 
                     'bf':'monospace:bold'})
mpl.rc('text', **{'usetex':False})

# For test purposes
grid_x, grid_y = np.mgrid[-3.0:1.0:0.01,-3:2:0.01]

# Some list of available ratios and associated 'readable' regions for 
# different kappas, recommended methods, limiting ranges
diagnostics = {'NII/SII;OIII/SII':
                   {'range':{10:(7.39,9.39,6.5,8.5), 
                             20:(7.39,9.39,6.5,8.5), 
                             50:(7.39,9.39,6.5,8.5), 
                             np.inf:(7.39,9.39,6.5,8.5)}, 
                    'z':'cubic','q':'linear',
                    'xliml':-1.25, 'xlimr':0.75, 'ylimb': -3.0, 'ylimt':2.0},
               'NII/SII;OIII/Hb':
                   {'range':{10:(7.39,9.39,6.5,8.5),
                             20:(7.39,9.39,6.5,8.5), 
                             50:(7.39,9.39,6.5,8.25),
                             np.inf:(7.39,9.39,6.5,8.5)},
                    'z':'cubic','q':'linear',
                    'xliml':-1.25, 'xlimr':0.75, 'ylimb': -3.0, 'ylimt':1.0},
               'NII/SII;OIII/OII':
                   {'range':{10:(7.39,9.39,6.5,8.5),
                             20:(7.39,9.39,6.5,8.5),
                             50:(7.39,9.39,6.5,8.5),
                             np.inf:(7.39,8.99,6.5,8.5)},
                    'z':'cubic','q':'cubic',
                    'xliml':-1.5, 'xlimr':0.75, 'ylimb': -2.25, 'ylimt':1.0},
               'NII/OII;OIII/OII':
                   {'range':{10:(7.39,9.39,6.5,8.25), 
                             20:(7.39,9.39,6.5,8.0), 
                             50:(7.39,9.39,6.5,7.75), 
                             np.inf:(7.39,9.39,6.5,7.75)},
                    'z':'cubic','q':'cubic',
                    'xliml':-2.0, 'xlimr':1.5, 'ylimb': -2.5, 'ylimt':1.0},
               'NII/OII;OIII/SII':
                   {'range':{10:(7.39,9.39,6.5,8.5), 
                             20:(7.39,9.39,6.5,8.5), 
                             50:(7.39,9.39,6.5,8.5), 
                             np.inf:(7.39,9.39,6.5,8.5)},
                    'z':'cubic','q':'cubic',
                    'xliml':-2.0, 'xlimr':1.0, 'ylimb': -3.0, 'ylimt':2.0},
               'NII/OII;OIII/Hb':
                   {'range':{10:(7.39,9.39,6.5,7.5), 
                             20:(7.39,9.39,6.5,7.5), 
                             50:(7.39,9.39,6.5,7.5), 
                             np.inf:(7.39,9.39,6.5,7.5)}, 
                    'z':'cubic','q':'cubic',
                    'xliml':-2.0, 'xlimr':1.5, 'ylimb': -3.0, 'ylimt':1.0},
               'NII/Ha;OIII/Hb':
                   {'range':{10:(7.39,8.69,6.5,8.5), 
                             20:(7.39,8.39,6.5,8.5), 
                             50:(7.39,8.39,6.5,8.25), 
                             np.inf:(7.39,8.39,6.5,8.5)},
                    'z':'cubic','q':'cubic',
                    'xliml':-3.5, 'xlimr':-0.5, 'ylimb': -2.0, 'ylimt':1.0},
               'NII/Ha;OIII/OII':
                   {'range':{10:(7.39,8.69,6.5,8.5), 
                             20:(7.39,8.39,6.5,8.5), 
                             50:(7.39,8.17,6.5,8.25), 
                             np.inf:(7.39,7.99,6.5,8.5)},
                    'z':'cubic','q':'cubic',
                    'xliml':-3.5, 'xlimr':-0.5, 'ylimb': -2.0, 'ylimt':0.75}
               }
# Supported kappa values
kappas = [10,20,50,np.inf]

# Grid nodes values for 12 + log(O/H) and log (q)
all_z = np.array([7.39,7.69,7.99,8.17,8.39,8.69,8.99,9.17,9.39])
all_q = np.array([6.5,6.75,7,7.25,7.5,7.75,8.0,8.25,8.5])

# Labels for the plots
plot_labels = {'OII': '[O\ \mathtt{II}]\ \lambda3726+\ \lambda3729',
               'OIII':'[O\ \mathtt{III}]\ \lambda5007',
               'Ha':  r'H \alpha',
               'Hb':  r'H \beta',
               'NII': '[N\ \mathtt{II}]\ \lambda6548',
               'SII': '[S\ \mathtt{II}]\ \lambda6716+\ \lambda6731'}

# Text files keys ... all need to have the same structure !
# Better idea anyone ... ?
keys = { 'z':0, 'q':1, 'OIII/Hb':2, 'OI/Ha':3, 'NII/Ha':4, 'SII/Ha':5, 
         'OIII/OII':6, 'OIII/NII':7, 'OIII/SII':8, 'NII/SII':9, 'SIII/SII':10,
         'NII/OII':11 }

# A function to get the reference grid - useful to make plots !
def get_grid(kappa,name1,name2):
    # 0) Check the input values ...
    if not(kappa in kappas)  :
        if kappa == 'inf': # if set as a string instead of an np.inf ...
            kappa = np.inf
        else :
            print ' Kappa value not supported.'
            return False
    for name in [name1,name2]:
        if not(name in keys):
            print 'Ratio '+name1+' not supported.'
            return False

    # 1) Get the grid in a numpy array format
    fn = pyqz_dir+'reference_data/photo_grid_k'+str(kappa)+'.txt'
    data = np.loadtxt(fn, comments='#', 
                      usecols = (keys['z'],keys['q'],keys[name1],keys[name2]))
    # 2) Send it back
    return data


# The main function - returns 'q' or'z' for a given ratio (and a given grid !)
# Interpolate slice by slice for even better results !
def get_qz (kappa, # which kappa value 
            qz, #'q' or 'z' 
            ratio1, ratio2, # line ratios -> must be numpy array ! 
            name1, name2, # Diagnostic names 
            method='default', # interpolation method : default, linear, cubic
            plot = False, # plot the results ?
            n_plot = False, # set a plot number ?
            savefig = False # save it ? yes -> savefig = filename !
            ):
    
    # 0) Do some preliminary checks ....
    diagnostic = name1+';'+name2
    if not(diagnostic in diagnostics):
        print ' Diagnostic not supported.'
        return False

    (zmin,zmax,qmin,qmax) = diagnostics[diagnostic]['range'][kappa]
    
    if not(kappa in kappas)  :
        if kappa == 'inf': # if set as a string instead of an np.inf ...
            kappa = np.inf
        else :
            print ' Kappa value not supported.'
            return False

    if qz!='q' and qz !='z' :
        print "qz value needs to be 'q' or 'z'. "
        return False

    if method == 'default':
        method = diagnostics[diagnostic][qz]

    if type(ratio1) != np.ndarray or type(ratio2) != np.ndarray :
        print " Input ratios must be Numpy array !"
        print " Current type (ratio1/ratio2):",type(ratio1),type(ratio2)
        return False
    else :
        ratios = [ratio1,ratio2]

    # 1-1) Load the corresponding data file
    data = get_grid(kappa, name1, name2)

    # 1-2) Only keep the 'readable' region ... i.e. no fold allowed !
    data = data[data[:,0]>=zmin,:]
    data = data[data[:,0]<=zmax,:]
    data = data[data[:,1]>=qmin,:]
    data = data[data[:,1]<=qmax,:]
        
    # 2-1) Now, get ready to do the interpolation-s ...
    if qz == 'z':
        var = 0
        loops = all_z[(all_z>=zmin) * (all_z<=zmax)] 
    if qz == 'q':
        var = 1
        loops = all_q[(all_q>=qmin) * (all_q<=qmax)] 

    # 2-2) Start the plot already ... will plot in the loop ...
    if plot :
        if n_plot :
            plt.close(n_plot)
            fig = plt.figure(n_plot, figsize=(10,8))
        else :
            plt.close()
            fig = plt.figure(figsize=(10,8))

        gs = gridspec.GridSpec(1,2, height_ratios=[1], width_ratios=[1,0.05])
        gs.update(left=0.14,right=0.88,bottom=0.14,top=0.92,wspace=0.1,hspace=0.1, )
            
        ax1 = fig.add_subplot(gs[0,0])  
        xlim1 = diagnostics[diagnostic]['xliml']
        xlim2 = diagnostics[diagnostic]['xlimr']
        ylim1 = diagnostics[diagnostic]['ylimb']
        ylim2 = diagnostics[diagnostic]['ylimt']

    # 2-3) To store the final results - fill it with nan-s ...
    grid_z_tot = np.sqrt(np.zeros_like(ratios[0])-1)

    # 2-4) Now, loop through every slice and do the interpolation ...
    # Slicing the grid ensure smoother results ... hopefully !
    for (l,loop) in enumerate(loops[:-1]):
        
        # 2-4a) Select the slice
        this_data = data[(data[:,var]>=loops[l]) * (data[:,var]<=loops[l+1]),:] 

        # 2-4b) Sretch slice between 0 and 1
        data_stretch = np.zeros_like(this_data)
        xmin = np.min(this_data[:,2])
        xmax = np.max(this_data[:,2]-xmin)
        ymin = np.min(this_data[:,3])
        ymax = np.max(this_data[:,3]-ymin)

        data_stretch[:,2] = (this_data[:,2]-xmin)/xmax
        data_stretch[:,3] = (this_data[:,3]-ymin)/ymax
    
        # 2-4c) Also do it for the input ratios
        sratios = np.zeros_like([ratios[0],ratios[1]], dtype = np.float)
        sratios[0] = (ratios[0]-xmin)/xmax
        sratios[1] = (ratios[1]-ymin)/ymax
    
        # 2-4d) Interpolate !
        grid_z = interpolate.griddata(data_stretch[:,2:4],this_data[:,var],
                                      (sratios[0],sratios[1]),method=method,
                                      fill_value=np.NaN)
        
        # 3) Check which point is 'inside the slice'. 
        # This is the bottleneck of the code (time-wise) !
        # 3-1) Define the region contour
        if var == 0:
            this_zmin = loops[l]
            this_zmax = loops[l+1]
            this_qmin = qmin
            this_qmax = qmax
        else :
            this_zmin = zmin
            this_zmax = zmax
            this_qmin = loops[l]
            this_qmax = loops[l+1]

        left = this_data[this_data[:,0]==this_zmin][:,2:4]
        left = left[left[:,1].argsort()]
    
        top = this_data[this_data[:,1]==this_qmax][:,2:4]
        top = top[top[:,0].argsort()]
        
        right = this_data[this_data[:,0]==this_zmax][:,2:4]
        right = right[right[:,1].argsort()[::-1]]
    
        bot = this_data[this_data[:,1]==this_qmin][:,2:4]
        bot = bot[bot[:,0].argsort()[::-1]]

        contour = np.append(left,top,axis=0)
        contour = np.append(contour,right,axis=0)
        contour = np.append(contour,bot,axis=0)
        
        # 3-2) Close the path

        for i in range(len(contour)-1):
            if i==0 :
                codes = [Path.MOVETO]
            else :
                codes.append(Path.LINETO)

        codes.append(Path.CLOSEPOLY)

        # 3-3) Create a Path
        path = Path(contour,codes)

        # 3-4) Remove points outside the region
        if len(np.shape(grid_z))==2:
            for (i,item) in enumerate(grid_z.flat):
                if grid_z.flat[i]*0 == 0 : # Check for NaN's
                    if path.contains_point((ratios[0].flat[i],
                                            ratios[1].flat[i]), radius=0)==0 :
                        # Just make sure we are not on the edges !
                        on_grid = False
                        for point in contour:
                            if (ratios[0].flat[i] == point[0]) and \
                                    (ratios[1].flat[i] == point[1]):
                                on_grid = True
                                break         
                        if not(on_grid) :
                            grid_z.flat[i] = np.NaN

        elif len(np.shape(grid_z))==1:
            for (i,item) in enumerate(grid_z):
                if grid_z[i]*0 == 0 :
                    if path.contains_point((ratios[0][i],ratios[1][i]), radius=0)==0:
                        # just make sure we are not on the edges !
                        on_grid = False
                        for point in contour:
                            if (ratios[0][i] == point[0]) and\
                                    (ratios[1][i] == point[1]):
                                on_grid = True
                                break         
                        if not(on_grid) :
                            grid_z[i] = np.NaN


        # 3-4) Store the cleaned interpolated values in the final array
        grid_z_tot[grid_z>0] = grid_z[grid_z>0]

        # 4) Plot for test purposes
        if plot :

            # 4-1) Valid region
            patch = patches.PathPatch(path, facecolor='none',edgecolor='k',
                                      lw=0.5)
            ax1.add_patch(patch)

            # 4-2) Grid points
            ref_pts = ax1.scatter(this_data[:,2],this_data[:,3],marker='o',
                                  c=this_data[:,var],
                                  s=40, cmap='Paired', edgecolor='k', 
                                  vmin=np.min(data[:,var]), 
                                  vmax=np.max(data[:,var]))
            # 4-3) Interpolated points
            if np.size(grid_z[grid_z == grid_z]) > 0:
                doplot = True # Not so useful anymore
            if len(np.shape(grid_z)) == 2 :
                try : 
                    test = [np.mean(ratios[0]-grid_x),np.mean(ratios[1]-grid_y)]
                except:
                    test = False

                if test == [0.,0.] : # Not perfect, but it should do the trick ...
                    pts = ax1.imshow(grid_z.T,origin='lower',cmap='Paired',
                                     interpolation='none',filterrad=1.0,
                                     extent=(-3,1,-3,2),aspect=2./3.,
                                     vmin=np.min(data[:,var]), 
                                     vmax=np.max(data[:,var]))
                else :
                    pts = ax1.scatter(ratios[0],ratios[1],marker='s', c=grid_z,
                                      s=40, cmap = 'Paired', edgecolor='none',
                                      vmin = np.min(data[:,var]),
                                      vmax = np.max(data[:,var]))
            elif len(np.shape(grid_z)) == 1:
                pts = ax1.scatter(ratios[0],ratios[1],marker='s',c=grid_z,
                                  s=40,cmap='Paired',edgecolor='k',
                                  vmin=np.min(data[:,var]), 
                                  vmax=np.max(data[:,var])) 
                
    # loop is over 
    # Finalize the plotting if necessary

    if plot :
        # Plot also the points outside the grid ?
        # Which are they - need to check if they have a valid input first !
        my_out_pts = []
        my_out_pts = (ratios[0] == ratios[0]) * (ratios[1] == ratios[1]) * \
            (grid_z_tot != grid_z_tot)

        if np.size(grid_z_tot[my_out_pts]) > 0 and \
                np.size(grid_z_tot[my_out_pts]) < 1500:
            out_pts = ax1.scatter(ratios[0][my_out_pts], 
                                  ratios[1][my_out_pts],
                                  marker = '^', facecolor = 'none', 
                                  edgecolor = 'k', s=40)
        # plot the colorbar
        cb_ax = plt.subplot(gs[0,1])
        cb = Colorbar(ax = cb_ax, mappable = ref_pts, orientation='vertical')
        # Colorbar legend
        if var == 0:
            cb.set_label(r'12+log(O/H)', labelpad = 10)
        elif var == 1:
            cb.set_label(r'log(q)', labelpad = 10) 

        # Axis names
        p = name1.index('/')
        ax1.set_xlabel(r'log $\frac{'+plot_labels[name1[:p]]+'}{'+\
                           plot_labels[name1[p+1:]]+'}$',
                       labelpad =10)
        p = name2.index('/')
        ax1.set_ylabel(r'log $\frac{'+plot_labels[name2[:p]]+'}{'+\
                           plot_labels[name2[p+1:]]+'}$',
                       labelpad = 10)
        ax1.set_xlim((xlim1,xlim2))
        ax1.set_ylim((ylim1,ylim2))
        ax1.set_aspect((xlim2-xlim1)/(ylim2-ylim1))
        if kappa != np.inf :
            ax1.set_title(r'$\kappa$='+str(kappa))
        else :
            ax1.set_title(r'$\kappa$=$\infty$')       
        ax1.grid(True)

        if savefig :
            plt.savefig(savefig, bbox_inches='tight')
        plt.show()
    return grid_z_tot

# Get the qz ratios from a file - mind the file structure !
def get_qzff(kappa,fn, decimals=5, output='csv'):
    starttime = dt.now()
    
    # 1) Get the different ratios and grids names
    file = open(fn, 'r')
    rats = file.readline()
    file.close()
    
    #Clean the end of the line
    if rats[-1:]=='\n' :
        rats=rats[:-1]
    # Split them
    if rats.index(' ') > 0:
        separator = ' '
    elif rats.index('\t') > 0:
        separator = '\t'
    else :
        print " Unknown column separator. Must be ' ' or 'tab'."
        print ' I will crash now.'
    
    rats = rats.split(separator) #requires 
    types = np.zeros_like(rats)
    for (i,rat) in enumerate(rats) :
        if rat in keys :
            types[i] = 'dat'
        elif rat in diagnostics :
            types[i] = 'diag'
        else :
            print 'Ratio unknown: ',rat
            print ' I will crash soon.'
    
            
    # 2) Get the actual data
    data = np.genfromtxt(fn,skiprows = 1, missing_values = '$$$', 
                         filling_values = np.nan)
    
    # 3) Create the final storage stucture
    npoints = len(data[:,0])
    final_data = np.zeros([npoints,
                           len(types[types=='dat'])+2*len(types[types=='diag'])+4])
    final_names = []
    
    for (i,type) in enumerate(types):
        if type == 'dat':
            final_names.append(rats[i])
        elif type == 'diag':
            final_names.append(rats[i]+'[log q]')
            final_names.append(rats[i]+'[log z]')
    
    final_names.append('<q>')
    final_names.append('d[q]')
    final_names.append('<z>')
    final_names.append('d[z]')

    # 3) Start doing the calculation
    for (i,calc) in enumerate(final_names):
        if calc in keys :
            final_data[:,i] = data[:,rats.index(calc)]
        elif calc[:-7] in diagnostics :
            qz = calc[-2]
            name1 = calc[:calc.index(';')]
            name2 = calc[calc.index(';')+1:calc.index('[')]
            rat1 = data[:,rats.index(name1)]
            rat2 = data[:,rats.index(name2)]
            qz_values = get_qz(kappa,qz,rat1,rat2,name1,name2)

            final_data[:,i] = qz_values

    # 4) Calculate mean q and z
    qs = []
    zs = []
    # Start by finding which columns I have to average
    for (i,name) in enumerate(final_names):
        if name[-7:]=='[log q]':
            qs.append(True)
            zs.append(False)
        elif name[-7:]=='[log z]':
            qs.append(False)
            zs.append(True)
        else:
            qs.append(False)
            zs.append(False)
            
    # Now get the mean and std for each value
    for (i,line) in enumerate(final_data):
        mean_q = stats.nanmean(final_data[i,np.array(qs)])
        std_q = stats.nanstd(final_data[i,np.array(qs)])
        mean_z = stats.nanmean(final_data[i,np.array(zs)])
        std_z = stats.nanstd(final_data[i,np.array(zs)])

        final_data[i,final_names.index('<q>')] = mean_q
        final_data[i,final_names.index('d[q]')] = std_q
        final_data[i,final_names.index('<z>')] = mean_z
        final_data[i,final_names.index('d[z]')] = std_z        

    # 5) Save the final data
    if output == 'txt':
        fn_out = fn[:-4]+'_out_k'+str(kappa)+fn[-4:]
        space = ' '
    elif output == 'csv':
        fn_out = fn[:-4]+'_out_k'+str(kappa)+'.csv'
        space = ' , '

    file = open(fn_out,'w')
    for name in final_names :
        file.write(name + space)
    file.write('\n')
    for line in final_data:
        for element in line :
            file.write(str(np.around(element,decimals=decimals))+space)
        file.write('\n')

    file.close()
    dtime = dt.now()-starttime
    print 'All done in',dtime.seconds,'s.'
    return final_names
    
# End of the World as we know it.

# This program retunrs the values of log(q) and z following the latest
# MAPPINGS IV simulations, and different kappa values.
#
# Installation: place the ./pyqz folder anywhere, and add its location
# to your Python path (e.g. in your .bash_profile for example).
#
# Usage example :
# 
# import pyqz
# pyqz.get_qz(kappa,qz,(ratios1,ratios2),ratio_name1, ratio_name2)
#
# To see the test plots :
#
# pyqz.get_qz(20,'z',(pyqz.grid_x,pyqz.grid_y),'NII/OII',
# 'OIII/SII',plot=True,method='default')
# 
#
# Keywords :
#
# kappa : the kappa value (required). print pyqz.kappas returns a list of 
# available kappa values
#
# qz : 'q' or 'z' (required). 
#
# (ratios1,ratios2) : your measured line ratios (required). Can be arrays,
# griddata, and more ? 
#
# ratio_name1,ratio_name2 : which ratios you have (required). X-AXIS IS 
# FIRST ! pyqz.diagnostics shows the allowed diagnostics. Format :
# NII/SII, OIII/Hb, etc ...
#
# plot : True/False (optional). For test purposes, you really should write your
# own plotting code ...
#
# method : 'default','linear','cubic' (optional). Which interpolation
# method to use (relies on scipy.interpolate.griddata)
#
#
# v0.1 created, Feb. 2013, F.Vogt (ref. files by D. Nicholls)
#
# To do : 
# - add more kappa values (i.e more reference files)

import numpy as np
import scipy as sp
from scipy import interpolate
from matplotlib import pyplot as plt
from matplotlib.path import Path
import matplotlib.patches as patches
import os

# Define the version of pyqz
__version__ = '0.1'

# If you set the environment variable 'PYQZ_DIR' then it will be found
mdir = os.getenv('PYQZ_DIR')
# OTHERWISE YOU MUST SET IT HERE BY HAND
if mdir == None:
    pyqz_dir = '/Users/fvogt/Tools/Python/fpav_pylib/pyqz/'
else:
    pyqz_dir = mdir

# For test purposes
grid_x, grid_y = np.mgrid[-2.0:1.0:0.01,-3:2:0.01]

# Some list of available ratios, recommended methods and allowed kappa values
diagnostics = ['NII/SII;OIII/SII','NII/SII;OIII/Hb', 'NII/SII;OIII/OII','NII/OII;OIII/OII', 
               'NII/OII;OIII/SII',]
methods = {'z':['cubic','cubic','cubic','cubic','cubic'],
           'q':['linear','linear','cubic','cubic','cubic']}

kappas = [20,np.inf]

# q and z limits ... required to define which regions can be interpolated ! 
zmax = 9.39
zmin = 7.39
qmax = 8.5
qmin = 6.5

# Text files keys ... all need to have the same structure !
# Better idea anyone ... ?
keys = { 'z':0, 'q':1, 'OIII/Hb':2, 'NII/Ha':3, 'SII/Ha':4, 'OIII/OII':5, 
         'OIII/NII':6, 'OIII/SII':7, 'NII/SII':8, 'NII/OII':9 }

# A function to get the reference grid - useful to make plots !
def get_grid(kappa,name1,name2):
    fn = pyqz_dir+'reference_data/photo_grid_k'+str(kappa)+'.txt'
    data = np.loadtxt(fn, comments='#', 
                      usecols = (keys['z'],keys['q'],keys[name1],keys[name2]))

    return data

# The main function - returns 'q' or'z' for a given ratio (and a given grid !)
def get_qz (kappa, qz, ratios, name1, name2, plot=False, method='default'):
    diagnostic = name1+';'+name2

    # 0) Do some preliminary checks ...
    if not(kappa in kappas)  :
        print ' Kappa value not supported.'
        return False
    if not(diagnostic in diagnostics):
        print ' Diagnostic not supported.'
        return False
    if qz!='q' and qz !='z' :
        print "qz value needs to be 'q' or 'z'. "
        return False

    if method == 'default':
        method = methods[qz][diagnostics.index(diagnostic)]

    # 1) Load the corresponding data file
    #fn = pyqz_dir+'reference_data/photo_grid_k'+str(kappa)+'.txt'
    #data = np.loadtxt(fn,comments = '#', 
    #                  usecols = (keys['z'],keys['q'],keys[name1],keys[name2]))
    data = get_grid(kappa, name1, name2)
        
    # 2) Now, do the interpolation

    if qz == 'z':
        var = 0
    if qz == 'q':
        var = 1

    grid_z = interpolate.griddata(data[:,2:4],data[:,var],
                             ratios,method=method,
                             fill_value=np.NaN)

    # 3) Check which point is 'inside the region'. 
    # This is the bottleneck of the code (time-wise) !
    # 3-1) Define the region contour
    left = data[data[:,0]==zmin][:,2:4]
    left = left[left[:,1].argsort()]
    
    top = data[data[:,1]==qmax][:,2:4]
    top = top[top[:,0].argsort()]
    
    right = data[data[:,0]==zmax][:,2:4]
    right = right[right[:,1].argsort()[::-1]]
    
    bot = data[data[:,1]==qmin][:,2:4]
    bot = bot[bot[:,0].argsort()[::-1]]

    contour = np.append(left,top,axis=0)
    contour = np.append(contour,right,axis=0)
    contour = np.append(contour,bot,axis=0)
        
    # 3-2) Close the path

    for i in range(len(contour)-1):
        if i==0 :
            codes = [Path.MOVETO]
        else :
            codes.append(Path.LINETO)

    codes.append(Path.CLOSEPOLY)

    # 3-3) Create a Path
    path = Path(contour,codes)

    # 3-4) Remove points outside the region
    if len(np.shape(grid_z))==2:
        for (i,item) in enumerate(grid_z.flat):
            if grid_z.flat[i]*0 == 0 :
                if path.contains_point((ratios[0].flat[i],ratios[1].flat[i]))==0:
                    grid_z.flat[i] = np.NaN
    elif len(np.shape(grid_z))==1:
        for (i,item) in enumerate(grid_z):
            if grid_z[i]*0 == 0 :
                if path.contains_point((ratios[0][i],ratios[1][i]))==0:
                    grid_z[i] = np.NaN

    # 4) Plot for test purposes
    if plot :
            plt.close(1)
            fig = plt.figure(1, figsize=(13,8))
            ax1 = fig.add_subplot(111)  
            # 4-1) Valid region
            patch = patches.PathPatch(path, facecolor='none',edgecolor='k',lw=1.5)
            ax1.add_patch(patch)

            # 4-2) Grid points
            ref_pts = plt.scatter(data[:,2],data[:,3],marker='o',c=data[:,var],
                                  s=20, cmap='Paired', edgecolor='k', 
                                  vmin=np.min(data[:,var]), vmax=np.max(data[:,var]))
        
            # 4-3) Data points
            if len(np.shape(grid_z)) == 2 :
                pts = plt.imshow(grid_z.T,origin='lower',cmap='Paired',
                                 interpolation='none',filterrad=1.0,
                                 extent=(-2,1,-3,2),aspect=0.5,
                                 vmin=np.min(data[:,var]), vmax=np.max(data[:,var]))
            elif len(np.shape(grid_z)) == 1:
                pts = plt.scatter(ratios[0],ratios[1],marker='s',c=grid_z,
                                s=20,cmap='Paired',edgecolor='k',
                                vmin=np.min(data[:,var]), vmax=np.max(data[:,var]))
            cbar = plt.colorbar(ref_pts)
            if var == 0:
                cbar.set_label('12-log(O/H)')
            elif var == 1:
                cbar.set_label('log(q)') 
            plt.xlabel('log ' + name1)
            plt.ylabel('log ' + name2)
            plt.grid(True)

    return grid_z


# End of the World as we know it.

  Python module : pyqz.py
  Version : 0.5.0 - Released November 2013 
  Copyright 2013 Fr�d�ric Vogt
 
  This file is part of the pyqz Python module.
 
    The pyqz Python module is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, version 3 of the License.
 
     The pyqz Pythonn module is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
 
     You should have received a copy of the GNU General Public License
     along with the pyqz Python module.  If not, see <http://www.gnu.org/licenses/>.
 
 ====================================================================================== 
  --------------------------------- README -------------------------------------------
 ======================================================================================

  -------------
  Introduction:
  This program returns the values of log(q) and 12+log(O/H) following the 
  latest MAPPINGS IV simulations, and different kappa values, as described in
 
  Dopita et al., New Strong Line Abundance Diagnostics for H ii Regions: 
  Effects of Updated Atomic Data and kappa-Distributed Electron Energies, 
  Apj (2013).
 
  -------------
  Installation: 
  Place the ./pyqz folder anywhere, and add its location
  to your Python path (e.g. in your .bash_profile for example). You should
  also define the global variable PYQZ_DIR (or directly modify line 84 of 
  the pyqz.py file if you don't have easy access to your Python path. 
 
  In my case (on a MAC OSX), my .bash_profile would look like :
 
  export PYTHONPATH=$PYTHONPATH:/Users/fvogt/Tools/Python/fpav_pylib/pyqz/
  export PYQZ_DIR='/Users/fvogt/Tools/Python/fpav_pylib/pyqz/'
 
  ----------------------------------
  Usage example (in a Terminal, via a Python shell):
 
  user% ipython --pylab
  user% import pyqz
 
  To see the test plots :
  user% pyqz.pyqz.get_qz(20,'z',pyqz.grid_x,pyqz.grid_y,'NII/OII', 'OIII/SII',plot=True,method='default')
 
  Or, for batch processing (with kappa = 20 in this example):
  user% pyqz.get_qzff(20,'Input.txt', output='txt')

  Or, for batch processing, but displaying and saving all the diagnostics in '.eps' figures as well:
  user% pyqz.get_qzff(20,'Input.txt', output='txt', plot=True, savefig=True, save_fmt='.eps')
 
  where input file has format similar to 'Input.txt'
 
  The exact list of ratios and diagnostic inside the input file is modifiable 
  (as long as any diagnostic is supported by pyqz, and the necessary line ratios are included).
  The file can contain extra columns (e.g. the name of the object), the initial line ratios, and which diagnostic 
  should be used. That is, THE FIRST LINE OF THE FILE CONTAINS MORE ITEMS THAN ANY OTHERS.
  In the example provided ('Input.txt'), we have 7 different spectrum (and associated line ratios, 
  and use all possible pyqz diagnostics to infer the mean values of q and 12+log(O/H).
  Missing values should be noted as '$$$'.
  get_qzff then outputs a .csv file "Input_out_k20.csv" with the output q and Z in the same directory
  Experienced Python users should be able to use pyqz in their script easily after importing the module.
 
  ----------
  Function : get_qz
  Syntax : get_qz(kappa,qz,ratios1,ratios2,ratio_name1, ratio_name2, method='default', plot=True/False, n_plot = False, savefig=False)
  Keywords :
    kappa : the kappa value (required). print pyqz.kappas returns a list of 
            available kappa values ; [10,20,60,np.inf]
 
    qz : 'q' or 'z' (required). Which grid to read; 
         'q' -> log(q) and 'z' -> 12+log(O/H) 
 
    ratios1,ratios2 : your measured line ratios (required). Needs to be a numpy array (1D or 2D) !
 
    ratio_name1,ratio_name2 : which ratios you have (required). X-AXIS IS  FIRST ! 
                              pyqz.diagnostics.keys() shows the allowed diagnostics. 
                              Format : 'NII/SII', 'OIII/Hb', etc ... 
                              Allowed ratios are : 
 	'NII/SII;OIII/SII',
 	'NII/SII;OIII/Hb', 
 	'NII/SII;OIII/OII',
 	'NII/OII;OIII/SII',
  	'NII/OII;OIII/Hb',
  	'NII/OII;OIII/OII',
 	'NII/Ha;OIII/Hb',
 	'NII/Ha;OIII/OII'
 
    plot : True/False (optional).
 
    method : 'default','linear','cubic' (optional). Which interpolation
              method to use (relies on scipy.interpolate.griddata)
 
    n_plot : False, 1, 2, 3, � . The number of the plot window created. 
             Setting to False will just take the next available slot.
 
    savefig : False, 'path/to/somehwere/figname.extension'. If False, does nothing. 
              Else, saves the figure at the location '/path/to/somewhere/', 
              with the name 'figname' and the format 'extension'. 
              Supports png, eps and pdf (and others).
 
  -- -- -- -- -- -- -- -- -- --	
  Function : get_qzff
  Syntax : get_qzff((kappa,fn,decimals=5, output='csv',plot = False,savefig=False,plot_loc = './', save_fmt = '.eps')
  Keywords :
    kappa : the kappa value (required). print pyqz.kappas returns a list of 
            available kappa values ; [10,20,60,np.inf]
 
    fn : filename to read (should be a string, a.k.a. 'myfile.txt'). The file structure should
         be similar to the example Input.txt
 
    decimals : number of decimals to print in the output. Default = 5

    output : 'csv' or 'txt' ('csv' = default) - the output file format 

    plot : True or False (False = default) - whether to make the plots or not
    savefig : True or False (False = default) - whether to save the plots or not
    plot_loc : path to where the plots should be saved ('./' = default)
    save_fmt : plot formats (e.g. '.eps', '.pdf', '.png'). '.eps' = default

  -----------------------
  More examples :
 
  To load a diagnostic grid (useful to plot it in a BPT diagram) :
  pyqz.get_grid(kappa,name1,name2)

  -----------------
  Troubleshooting :
 
  While this code should be fairly straightforward to use, limited support may
  (or may not ...;-) be available by contacting 'frederic.vogt -at- anu.edu.au'.
  Bug reports are always welcome, though !
 
  -----------
  Reference :
 
  If you find this code useful, please cite the corresponding paper
 
  Dopita et al., ApJ (2013).
 
 

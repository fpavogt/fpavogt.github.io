
###
# This program will let you plot an interactive 3-D maps
# To save it in a .pdf, I have used Adobe Acrobat 9 Pro extended and the
# "direct capture" option. It's ugly, but the .vrml produce by Python does
# not work with Adobe (it SHOULD) ...
# If you have any questions : fvogt@mso.mso.anu.edu
# Have fun !
#
# If you find this code useful, please cite :
# 
# Vogt & Dopita, ApJ 721, 597 (2010) and
# Vogt & Dopita, Ap&SS 331, 521 (2011)
#
# Created by Frederic Vogt, 22.11.2011 - fvogt 'at' mso.anu.edu.au
#
###

from enthought.tvtk.api import tvtk
from enthought.mayavi import mlab
from enthought.mayavi import modules
import pyfits
import numpy as np

# From here, it's just cleaning and stuff.
# I do it twice, for [O III] and Hbeta.

# Reference wavelength
lambda0=5012
#Conversion factor : slice to wavelength (based on fits header)
slicetowave=0.817255 

cc=299792.458 #Speed of light in [km/s]

def slicetov (vector):
    
    vector=(slicetowave*(vector-63))+5012
    return -(vector-lambda0)/lambda0*cc

def vtoslice (v):
    v=v/cc*lambda0#to get delta lambda
    return v/slicetowave

def pixtodec (vector) :#based on ref star position B

    return ((vector-47.10)*0.5/3600.)-72.035194

def pixtora (vector) :#based on ref star position B
    
    return ((vector-28.82)*0.5/3600.)+15.987283

#For Hbeta
lambda0beta=4866.5

def slicetovbeta (vector):
    vector=(slicetowave*(vector-74))+4866.5
    return -(vector-lambda0beta)/lambda0beta*cc

#Loading the file
hdulist=pyfits.open('mosaic_final_0705.fits')
print "--------------------"
print "Master cube opened !"
print "--------------------"

print hdulist.info()

#Loading the array
scidata=hdulist['PRIMARY'].data
print scidata.shape

n_slice=scidata.shape[0]
size_y=scidata.shape[1]
size_x=scidata.shape[2]


hdulist.close()

#Loading Hbeta cube :
hdulist=pyfits.open('mosaic_init_rot_0705.fits')
print "--------------------"
print "Master cube opened !"
print "--------------------"

print hdulist.info()

#Loading the array
scidatabeta=hdulist['PRIMARY'].data
print scidatabeta.shape

n_slicebeta=scidata.shape[0]
size_ybeta=scidata.shape[1]
size_xbeta=scidata.shape[2]


hdulist.close()
########################

delta=30
slice_min=0
slice_max=n_slice-delta

print slice_min
print slice_max

data10=np.array([0,0,0,0])

yes10=True

# Here, I simply loop through the cube, ans select the pixels above a certain
# intensity.

for nslice in np.arange(slice_min,slice_max,1):
    
        print nslice
        for line in np.arange(0,size_x,1):
            for column in np.arange(0,size_y,1):

                pixel=scidata[nslice,column,line]
                tmp=[line,column,slicetov(nslice),pixel]
                
                # Here I select them : pixel is the intensity boundaries
                # and tmp is the slice number, i.e. I take only the [OIII] line
                # I used Qfits view to check my cube and find those parameters.
                if pixel>6 and pixel <=20 and (tmp[2]<-100 or tmp[2]>100):
                    if yes10 :
                        data10=tmp
                        yes10=False
                    else :
                        data10=np.vstack((data10,tmp))

# Extract the Hbeta cube in a similar fashion #######


slice_min_beta=delta-19
slice_max_beta=130
data10beta=np.array([0,0,0,0])

yes10beta=True

#Loop throught the cube ...
for nslice in np.arange(slice_min_beta,slice_max_beta,1):
    
        print nslice
        for line in np.arange(0,size_xbeta,1):
            for column in np.arange(0,size_ybeta,1):
                pixel=scidatabeta[nslice,column,line]
                tmp=[line,column,slicetovbeta(nslice),pixel]
                
                #Other line means new intensity cuts 
                if pixel>8 and pixel <=20 and (tmp[2] < -100 or tmp[2]>100):
                    if yes10beta :
                        data10beta=tmp
                        yes10beta=False
                    else :
                        data10beta=np.vstack((data10beta,tmp))


age=2500 #in years, the explosion date of SNR N132D
vtor=age*365*24*3600 #km/s to km
kmtopc=3.24077649*10**(-14) #km to pc
astopc=0.24240684 #" to pc

size=(data10[:,0]-data10[:,0])+0.07
size2=(data10beta[:,0]-data10beta[:,0])+0.07


################################################################
# Now the interesting part : the plotting !
################################################################

mlab.figure()

# Don't be scared by the crap. It's just quiver3d(x,y,z). All the rest define point sizes
# and colors and so on. Check the MayaVi help for details. Note that this is the most basic
# possible plot, and there is much more that can be done ! It's worth the look !

# In the details, I transform my data into a pc scaled cube. 
# mode=2dcircle ensure that it is not too big to handle (there's many points, so, 
# using spheres woould be very slow).
# size defines the size of the circles, and scalars their colors. Here, I have their color as a
# function of the line intensity.

# Plot the [OIII] line
pts=mlab.quiver3d((data10[:,0]-size_x/2)*0.5*astopc,\
                (data10[:,1]-size_y/2)*0.5*astopc,(data10[:,2]*vtor*kmtopc),\
                size,size,size,scalars=data10[:,3]/max(data10[:,3]), mode='2dcircle',\
                scale_factor=1, opacity=0.1, colormap='winter')

# Plot the Hbeta line
pts2=mlab.quiver3d((data10beta[:,0]-size_x/2)*0.5*astopc,\
                (data10beta[:,1]-size_y/2)*0.5*astopc,(data10beta[:,2]*vtor*kmtopc),\
                size2,size2,size2,scalars=data10beta[:,3]/max(data10beta[:,3]), mode='2dcircle',\
                scale_factor=1, opacity=0.1, colormap='autumn')

pts.glyph.color_mode='color_by_scalar'
pts.glyph.glyph_source.glyph_source.center=[0,0,0]
pts2.glyph.color_mode='color_by_scalar'
pts2.glyph.glyph_source.glyph_source.center=[0,0,0]


mlab.show()

#The file format that should be able to be read by Adobe 9 Pro extended
#mlab.savefig('n132d.vrml') # To be used with Meshalb, eventually. 
#mlab.savefig('n132d.obj')  # In my case, does not save the colors. Check the n132d.mtl file
# and see if all the numbers are 1 (all is white), or not.

